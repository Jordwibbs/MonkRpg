#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

class Character {
public:
    string name;
    int health;
    int attackPower;
    int defense;
    
    Character(string n, int h, int a, int d) : name(n), health(h), attackPower(a), defense(d) {}
    
    virtual void attack(Character &target) {
        int damage = attackPower - (target.defense / 2);
        if (damage < 0) damage = 0;
        target.health -= damage;
        cout << name << " attacks " << target.name << " for " << damage << " damage!\n";
    }
    
    bool isAlive() {
        return health > 0;
    }
};

class Monk : public Character {
public:
    Monk(string n) : Character(n, 100, 15, 5) {}
    
    void heal() {
        int healAmount = 10;
        health += healAmount;
        cout << name << " meditates and heals for " << healAmount << " health!\n";
    }
};

class Enemy : public Character {
public:
    Enemy(string n, int h, int a, int d) : Character(n, h, a, d) {}
};

void battle(Monk &player, Enemy &enemy) {
    while (player.isAlive() && enemy.isAlive()) {
        cout << "\n" << player.name << "'s Health: " << player.health << "\t" << enemy.name << "'s Health: " << enemy.health << "\n";
        cout << "Choose an action: 1) Attack  2) Heal\n";
        int choice;
        cin >> choice;
        
        if (choice == 1) {
            player.attack(enemy);
        } else if (choice == 2) {
            player.heal();
        } else {
            cout << "Invalid choice, you miss your turn!\n";
        }
        
        if (enemy.isAlive()) {
            enemy.attack(player);
        }
    }
    
    if (player.isAlive()) {
        cout << "\nYou have defeated " << enemy.name << "!\n";
    } else {
        cout << "\nYou have been defeated by " << enemy.name << "...\n";
    }
}

void exploreRoom(Monk &player) {
    int event = rand() % 3; 
    switch (event) {
        case 0:
            cout << "You find an ancient scroll and gain wisdom, restoring some health!\n";
            player.health += 15;
            break;
        case 1: {
            cout << "A shadowy figure emerges! Prepare for battle!\n";
            Enemy enemy("Shadow Assassin", 70, 14, 6);
            battle(player, enemy);
            break;
        }
        case 2:
            cout << "The room is empty, but you feel at peace. Nothing happens.\n";
            break;
    }
}

int main() {
    srand(time(0));
    cout << "Enter your monk's name: ";
    string name;
    cin >> name;
    
    Monk player(name);
    
    while (player.isAlive()) {
        cout << "\nYou are in a monastery with multiple paths. Choose an action: 1) Explore a new room  2) Rest  3) Quit\n";
        int choice;
        cin >> choice;
        
        if (choice == 1) {
            exploreRoom(player);
        } else if (choice == 2) {
            cout << "You rest and regain some strength.\n";
            player.health += 20;
        } else if (choice == 3) {
            cout << "You decide to end your journey. Farewell, monk.\n";
            break;
        } else {
            cout << "Invalid choice. Try again.\n";
        }
    }
    
    cout << "Game Over.\n";
    return 0;
}
